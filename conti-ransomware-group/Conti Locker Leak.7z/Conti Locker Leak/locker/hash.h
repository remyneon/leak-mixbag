#pragma once

unsigned int MurmurHash2A(const void* key, int len, unsigned int seed);